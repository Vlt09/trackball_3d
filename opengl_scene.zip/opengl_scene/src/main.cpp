#define GLFW_INCLUDE_NONE
#include <iostream>
#include <fstream>
#include <string>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include "include/Camera.hpp"
#include "include/Renderer.hpp"
#include "include/Sphere.hpp"
#include "include/Quad.hpp"
#include "include/Box.hpp"
#include "include/Room.hpp"
#include "include/Skybox.hpp"

#include <GLFW/glfw3.h>
#include <glad/glad.h>
#include <glimac/glm.hpp>
#include <glimac/Program.hpp>
#include <glimac/FilePath.hpp>
#include <glimac/Image.hpp>
#include <glimac/getTime.hpp>
int window_width = 800;
int window_height = 800;

float last_xpos = 400;
float last_ypos = 400;
bool first_mouse = true;
float deltaTime = 0.0f;
float lastFrame = 0.0f;

float xMax = 10.f;
float xMin = -34.f;
float zMax = 10.f;
float zMin = -10.f;

bool firstRoomFlag = true;

Camera camera{};
std::vector<glimac::BBox3f> bboxVector;

std::vector<float> coordinateFromLine(char *line)
{
    float coordinate[7];
    std::string str(line);

    if (str.empty())
    {
        std::cout << "Pb str is empty" << std::endl;
    }

    size_t endLineIdx = str.find_first_of('\n');
    if (endLineIdx <= 0)
    {
        std::cout << "Error : bad line" << std::endl;
    }

    auto str2 = str.substr(0, endLineIdx - 1);
    char *p = const_cast<char *>(str2.c_str());

    char *strCoordinate = std::strtok(p, ",");
    for (int i = 0; strCoordinate != nullptr; strCoordinate = std::strtok(nullptr, ","))
    {
        coordinate[i] = std::stof(strCoordinate);
        i++;
    }

    return std::vector<float>{coordinate[0], coordinate[1], coordinate[2], coordinate[3],
                              coordinate[4], coordinate[5], coordinate[6]};
}

void updateDeltaTime()
{
    float currentFrame = glimac::getTime();
    deltaTime = currentFrame - lastFrame;
    lastFrame = currentFrame;
}

bool checkCollision(const glm::vec3 &position)
{

    if ((position.x < -10.f && position.x > -12.f) && (position.z >= 2.f || position.z <= -2.f))
    {
        return true;
    }

    if ((position.x < -32.f || position.x > 10.f))
    {
        return true;
    }

    if (position.z < -12.f || position.z > 12.f)
    {
        return true;
    }
    if (position.z > -2. && position.z < 2.)
    {
        if (position.x < -32.f || position.x > 10.f)
        {
            return true;
        }
    }

    return false;
}

static void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods)
{
    glm::vec3 nextPos;
    if (action == GLFW_PRESS || action == GLFW_REPEAT)
    {
        switch (key)
        {
        case GLFW_KEY_W:
            nextPos = camera.nextMoveUp(1.);
            // if (!checkCollision(nextPos))
            // {
            camera.moveUp(1.);
            // }
            break;
        case GLFW_KEY_A:
            nextPos = camera.nextMoveLeft(1.f);
            // if (!checkCollision(nextPos))
            // {
            camera.moveLeft(1.);
            // }
            break;
        case GLFW_KEY_S:
            nextPos = camera.nextMoveUp(-1.f);
            // if (!checkCollision(nextPos))
            // {
            camera.moveUp(-1.);
            // }
            break;
        case GLFW_KEY_D:
            nextPos = camera.nextMoveLeft(-1.f);
            // if (!checkCollision(nextPos))
            // {
            camera.moveLeft(-1.);
            // }
            break;
        case GLFW_KEY_E:
            camera.rotateLeft(-15.);
            break;
        case GLFW_KEY_Q:
            camera.rotateLeft(15.f);
            break;
        }
    }
}

static void mouse_button_callback(GLFWwindow * /*window*/, int /*button*/, int /*action*/, int /*mods*/)
{
}

static void scroll_callback(GLFWwindow * /*window*/, double /*xoffset*/, double /*yoffset*/)
{
}

static void cursor_position_callback(GLFWwindow *window, double xpos, double ypos)
{
    if (first_mouse)
    {
        last_xpos = xpos;
        last_ypos = ypos;
        first_mouse = false;
    }

    camera.rotateLeft(xpos - last_xpos);
    camera.rotateUp(last_ypos - ypos);

    last_xpos = xpos;
    last_ypos = ypos;
}

static void size_callback(GLFWwindow * /*window*/, int width, int height)
{
    window_width = width;
    window_height = height;
}

int main(int argc, char *argv[])
{
    /* Initialize the library */
    if (!glfwInit())
    {
        return -1;
    }

    /* Create a window and its OpenGL context */
    // #ifdef __APPLE__
    //     /* We need to explicitly ask for a 3.3 context on Mac */
    //     glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    //     glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    //     glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    //     glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    // #endif
    GLFWwindow *window = glfwCreateWindow(window_width, window_height, "2 salles 2 ambiances", nullptr, nullptr);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    int fd = open("/home/valentin/m2/geometrie_projective/opengl_scene/fifo_trackball", O_RDONLY);
    if (fd == -1)
    {
        std::cerr << "Erreur lors de l'ouverture du fichier" << std::endl;
        return 1;
    }
    int DATA_SIZE_MAX = 30;
    char data[255];

    /* Make the window's context current */
    glfwMakeContextCurrent(window);

    /* Intialize glad (loads the OpenGL functions) */
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        return -1;
    }

    glimac::FilePath applicationPath(argv[0]);

    glEnable(GL_DEPTH_TEST);
    /* Hook input callbacks */
    glfwSetKeyCallback(window, &key_callback);
    glfwSetMouseButtonCallback(window, &mouse_button_callback);
    glfwSetScrollCallback(window, &scroll_callback);
    glfwSetCursorPosCallback(window, &cursor_position_callback);
    glfwSetWindowSizeCallback(window, &size_callback);

    glm::mat4 proj_matrix = glm::perspective(glm::radians(70.f), (float)window_width / window_height, 0.1f, 100.f);
    auto viewMatrix = camera.getViewMatrix();

    auto firstRoom_light_posY = camera.cameraPosition().y + 10.f;

    Renderer renderer(proj_matrix, viewMatrix);
    Skybox skybox(applicationPath);
    Room fr, sr;

    /* Init first Box*/
    fr.initFirstRoom(applicationPath.dirPath() + "src/shaders/3D.vs.glsl",
                     applicationPath.dirPath() + "src/shaders/directionallight.fs.glsl",
                     camera.cameraPosition(), bboxVector, applicationPath);

    fr.translateSpotLight(glm::vec3(camera.cameraPosition().x, firstRoom_light_posY, camera.cameraPosition().z), 0);
    fr.setSpotLightDirection(camera.cameraPosition(), 0);
    fr.translateSpotLight(glm::vec3(camera.cameraPosition().x, firstRoom_light_posY + 5.f, camera.cameraPosition().z), 1);

    fr.translateSpotLight(glm::vec3(camera.cameraPosition().x, firstRoom_light_posY, camera.cameraPosition().z - 5.f), 1);
    fr.setSpotLightDirection(glm::vec3(camera.cameraPosition().x, 0., camera.cameraPosition().z - 5.f), 1);

    fr.setGlobalLightPos(glm::vec3(camera.cameraPosition().x, firstRoom_light_posY, camera.cameraPosition().z));

    auto cPos = camera.cameraPosition();
    glm::vec3 border = glm::vec3(cPos.x - 12, cPos.y, cPos.z);
    glm::vec3 move(0.f, 0.f, 15.f);

    fr._sphere.initTexture(applicationPath.dirPath() + "../src/assets/tennis.jpg");
    fr._sphere.translateMesh(move, 0);

    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {
        size_t nbBytes = read(fd, data, 255);
        if (nbBytes <= 0)
        {
            // std::cerr << "Warning read 0 byte or error during reading" << std::endl;
        }
        else
        {
            // std::cout << "Data = " << data << std::endl;
            auto transformationData = coordinateFromLine(data);

            glm::vec3 sphereCoor(transformationData[0], transformationData[1], transformationData[2]);
            glm::vec3 direction(transformationData[4], transformationData[5], transformationData[6]);
            float angle = transformationData[3];
            std::cout << "Received position :" << sphereCoor << std::endl;
            std::cout << "Received rotation :" << direction << " angle = " << angle << std::endl;

            fr._sphere.translateMesh(sphereCoor, 0);
            if (angle != 0.)
            {
                fr._sphere.rotateMesh(angle, direction, 0);
            }
        }

        renderer.setViewMatrix(camera.getViewMatrix());

        glClearColor(1.f, 0.5f, 0.5f, 1.f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        renderer.renderSkybox(skybox);
        renderer.renderFirstRoom(fr, camera.cameraPosition(), border);

        /* Swap front and back buffers */
        glfwSwapBuffers(window);
        /* Poll for and process events */
        glfwPollEvents();
        updateDeltaTime();
    }
    fr.clearBuffers();
    sr.clearBuffers();

    glfwTerminate();
    return 0;
}